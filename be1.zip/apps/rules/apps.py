from django.apps import AppConfig


class RulesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.rules'
    label = 'rules'
    verbose_name = 'Rules'
