from django.db import models
from django.conf import settings
from django.utils import timezone


class BlockedApp(models.Model):
    """An app to block during focus sessions (Android integration)."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='blocked_apps'
    )
    app_name = models.CharField(max_length=200)
    package_name = models.CharField(max_length=300)  # Android package name
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'blocked_apps'
        unique_together = ['user', 'package_name']

    def __str__(self):
        return self.app_name


class BlockedWebsite(models.Model):
    """A website to block during focus sessions."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='blocked_websites'
    )
    url = models.URLField(max_length=500)
    domain = models.CharField(max_length=300)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'blocked_websites'
        unique_together = ['user', 'domain']

    def __str__(self):
        return self.domain


class WhitelistApp(models.Model):
    """Apps allowed during focus mode (whitelist approach)."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='whitelist_apps'
    )
    app_name = models.CharField(max_length=200)
    package_name = models.CharField(max_length=300)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'whitelist_apps'
        unique_together = ['user', 'package_name']

    def __str__(self):
        return self.app_name


class WhitelistWebsite(models.Model):
    """Websites allowed during focus mode."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='whitelist_websites'
    )
    url = models.URLField(max_length=500)
    domain = models.CharField(max_length=300)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'whitelist_websites'
        unique_together = ['user', 'domain']


class FocusSchedule(models.Model):
    """
    A pre-set ("scheduled") Focus session: "6:00 AM, 30 minutes, Bible + prayer".

    The phone rings at [start_time] on each of [days] (1=Mon .. 7=Sun; empty =
    once, on [once_date]) until the user presses Start. The schedule lives on
    the account so it survives clearing the app's data.
    """
    PURPOSE_CHOICES = [('bible', 'Bible reading'), ('prayer', 'Prayer'), ('both', 'Bible + prayer')]
    DAY_CHOICES = [
        (0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'),
        (3, 'Thursday'), (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='focus_schedules'
    )
    title = models.CharField(max_length=120, blank=True)
    purpose = models.CharField(max_length=10, choices=PURPOSE_CHOICES, default='both')
    # Legacy single-day column (kept so old rows keep working).
    day_of_week = models.IntegerField(choices=DAY_CHOICES, null=True, blank=True)
    days = models.JSONField(default=list, blank=True)  # [1..7], Monday=1
    once_date = models.DateField(null=True, blank=True)
    start_time = models.TimeField()
    end_time = models.TimeField(null=True, blank=True)
    duration_minutes = models.PositiveIntegerField(default=30)
    ringtone = models.CharField(max_length=300, blank=True)  # label only; the sound itself lives on the phone
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'focus_schedules'
        ordering = ['start_time', 'id']

    def __str__(self):
        return f'{self.title or "Focus"} {self.start_time} ({self.duration_minutes} min)'

    def save(self, *args, **kwargs):
        from datetime import datetime, timedelta
        if self.start_time and self.duration_minutes:
            end = datetime.combine(datetime(2000, 1, 1).date(), self.start_time) + timedelta(minutes=self.duration_minutes)
            self.end_time = end.time()
        super().save(*args, **kwargs)


class FocusSession(models.Model):
    """A single focus session record."""
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('interrupted', 'Interrupted'),
        ('cancelled', 'Cancelled'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='focus_sessions'
    )
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    duration_minutes = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    blocked_attempts = models.PositiveIntegerField(default=0)
    # What the time was for: '' (plain focus), bible, prayer or both.
    purpose = models.CharField(max_length=10, blank=True, default='')

    class Meta:
        db_table = 'focus_sessions'
        ordering = ['-started_at']

    def __str__(self):
        return f'Focus {self.started_at.date()} - {self.duration_minutes}min'

    @property
    def time_saved_minutes(self):
        """Calculate estimated time saved by blocking distractions."""
        return self.blocked_attempts * 2  # estimate 2 min per blocked attempt

    def end_session(self, status='completed'):
        self.ended_at = timezone.now()
        self.duration_minutes = int((self.ended_at - self.started_at).total_seconds() / 60)
        self.status = status
        self.save(update_fields=['ended_at', 'duration_minutes', 'status'])


class BlockedAttempt(models.Model):
    """Records a blocked attempt to access a restricted app/website."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='blocked_attempts'
    )
    session = models.ForeignKey(
        FocusSession, on_delete=models.CASCADE, null=True, blank=True, related_name='attempts'
    )
    target_type = models.CharField(max_length=20, choices=[('app', 'App'), ('website', 'Website')])
    target_name = models.CharField(max_length=300)
    attempted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'blocked_attempts'
        ordering = ['-attempted_at']

    def __str__(self):
        return f'Blocked {self.target_type}: {self.target_name}'


class WebsiteProtectionKey(models.Model):
    """
    The user's Safe Browsing Key. Created ONCE, kept on the account (as a
    salted hash, never the key itself) so clearing the app's data or
    reinstalling can never remove it. Wrong-attempt counting and the lockout
    live here too, so they cannot be reset from the phone.
    """
    MAX_ATTEMPTS = 5
    LOCK_SECONDS = 300

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='website_protection_key'
    )
    key_hash = models.CharField(max_length=256)
    failed_attempts = models.PositiveSmallIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'website_protection_keys'

    def __str__(self):
        return f'Website key for {self.user_id}'

    def locked_seconds(self):
        if self.locked_until and self.locked_until > timezone.now():
            return int((self.locked_until - timezone.now()).total_seconds()) + 1
        return 0
